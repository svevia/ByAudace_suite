#!/bin/sh

mvn jetty:stop
