#!/bin/sh

cd /root/ByAudace-suite/webserver
mvn jetty:run
