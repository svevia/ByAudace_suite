package com.audace.byaudace;

/**
 * Created by svevia on 01/08/2016.
 */
public class Configuration {
    public static String SERVER = "http://audace.aureliensvevi.fr";
}
